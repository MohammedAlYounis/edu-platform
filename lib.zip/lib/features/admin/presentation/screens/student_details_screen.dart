import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/routing/app_router.dart';
import '../../../../shared/widgets/state_views.dart';
import '../../../../shared/widgets/status_badge.dart';
import '../../application/admin_providers.dart';
import '../../data/admin_repository.dart';

class StudentDetailsScreen extends ConsumerWidget {
  final String studentId;
  const StudentDetailsScreen({super.key, required this.studentId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final studentAsync = ref.watch(studentDetailsProvider(studentId));
    final submissionsAsync = ref.watch(studentSubmissionsProvider(studentId));

    return Scaffold(
      appBar: AppBar(title: const Text('ملف الطالب')),
      body: studentAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => ErrorStateView(
          message: 'تعذر تحميل بيانات الطالب.',
          onRetry: () => ref.invalidate(studentDetailsProvider(studentId)),
        ),
        data: (student) => ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text(student.fullName, style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 8),
            Text('الرقم الجامعي: ${student.studentNumber ?? "—"}'),
            Text('البريد: ${student.email}'),
            const SizedBox(height: 16),
            SwitchListTile(
              title: const Text('الحساب مفعّل'),
              value: student.isActive,
              onChanged: (value) async {
                await ref.read(adminRepositoryProvider).setStudentActive(studentId, value);
                ref.invalidate(studentDetailsProvider(studentId));
              },
            ),
            const SizedBox(height: 20),
            const Divider(),
            const SizedBox(height: 12),
            Text('الحلول المرسلة', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            submissionsAsync.when(
              loading: () => const LinearProgressIndicator(),
              error: (e, _) => const Text('تعذر تحميل الحلول.'),
              data: (rows) {
                if (rows.isEmpty) return const Text('لا توجد حلول مرسلة بعد.');
                return Column(
                  children: rows
                      .map((r) => Card(
                            child: ListTile(
                              title: Text(r.examTitle),
                              subtitle:
                                  Text(r.grade != null ? '${r.grade!.toStringAsFixed(0)}/100' : ''),
                              trailing: StatusBadge(status: r.status),
                              onTap: () => context.push(
                                AdminRoutes.reviewSubmission.replaceFirst(':id', r.id),
                              ),
                            ),
                          ))
                      .toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
