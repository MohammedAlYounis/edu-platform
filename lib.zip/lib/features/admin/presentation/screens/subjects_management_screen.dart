import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/routing/app_router.dart';
import '../../../../shared/widgets/state_views.dart';
import '../../application/admin_providers.dart';
import '../../data/admin_repository.dart';

class SubjectsManagementScreen extends ConsumerWidget {
  const SubjectsManagementScreen({super.key});

  Future<void> _showSubjectForm(BuildContext context, WidgetRef ref, {int nextOrder = 0}) async {
    final titleController = TextEditingController();
    final descController = TextEditingController();

    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('إضافة مادة'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: titleController, decoration: const InputDecoration(labelText: 'العنوان')),
            const SizedBox(height: 8),
            TextField(controller: descController, decoration: const InputDecoration(labelText: 'الوصف (اختياري)')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حفظ')),
        ],
      ),
    );

    if (saved != true || titleController.text.trim().isEmpty) return;

    await ref.read(adminRepositoryProvider).createSubject(
          title: titleController.text.trim(),
          description: descController.text.trim().isEmpty ? null : descController.text.trim(),
          orderIndex: nextOrder,
        );
    ref.invalidate(allSubjectsAdminProvider);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final subjectsAsync = ref.watch(allSubjectsAdminProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('المواد والمحتوى')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showSubjectForm(
          context,
          ref,
          nextOrder: subjectsAsync.valueOrNull?.length ?? 0,
        ),
        icon: const Icon(Icons.add),
        label: const Text('إضافة مادة'),
      ),
      body: subjectsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => ErrorStateView(
          message: 'تعذر تحميل المواد.',
          onRetry: () => ref.invalidate(allSubjectsAdminProvider),
        ),
        data: (subjects) {
          if (subjects.isEmpty) return const EmptyState(message: 'لا توجد مواد بعد.');
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: subjects.length,
            itemBuilder: (context, index) {
              final subject = subjects[index];
              return Card(
                child: ListTile(
                  title: Text(subject.title),
                  subtitle: Text(subject.description ?? ''),
                  trailing: Switch(
                    value: subject.isActive,
                    onChanged: (value) async {
                      await ref.read(adminRepositoryProvider).setSubjectActive(subject.id, value);
                      ref.invalidate(allSubjectsAdminProvider);
                    },
                  ),
                  onTap: () => context.push(
                    AdminRoutes.contentManagement.replaceFirst(':id', subject.id),
                    extra: subject.title,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
