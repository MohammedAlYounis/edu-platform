import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:reactive_forms/reactive_forms.dart';

import '../../../../core/constants/app_enums.dart';
import '../../../../core/localization/localization_extension.dart';
import '../../data/admin_repository.dart';

/// بند 33: عنوان + نص + هدف (الكل / مادة معيّنة / طالب معيّن).
/// إرسال الـ FCM push الفعلي يُبنى في Phase 6؛ هنا فقط إنشاء السجل.
class AdminNotificationsScreen extends ConsumerStatefulWidget {
  const AdminNotificationsScreen({super.key});

  @override
  ConsumerState<AdminNotificationsScreen> createState() => _AdminNotificationsScreenState();
}

class _AdminNotificationsScreenState extends ConsumerState<AdminNotificationsScreen> {
  final form = FormGroup({
    'title': FormControl<String>(validators: [Validators.required]),
    'body': FormControl<String>(validators: [Validators.required]),
  });

  bool _isSending = false;

  Future<void> _send() async {
    if (form.invalid) {
      form.markAllAsTouched();
      return;
    }
    setState(() => _isSending = true);
    try {
      await ref.read(adminRepositoryProvider).createNotification(
            title: form.control('title').value as String,
            body: form.control('body').value as String,
            type: NotificationType.general,
          );
      form.reset();
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(context.t('notification_sent'))));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(context.t('notification_send_failed'))));
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.t('new_notification'))),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ReactiveForm(
          formGroup: form,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              ReactiveTextField<String>(
                formControlName: 'title',
                decoration: InputDecoration(labelText: context.t('notification_title')),
              ),
              const SizedBox(height: 12),
              ReactiveTextField<String>(
                formControlName: 'body',
                maxLines: 4,
                decoration: InputDecoration(labelText: context.t('notification_body')),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _isSending ? null : _send,
                child: _isSending
                    ? const SizedBox(
                        height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : Text(context.t('send_to_all_students')),
              ),
              const SizedBox(height: 8),
              Text(
                context.t('notification_target_note'),
                style: const TextStyle(color: Colors.grey, fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
