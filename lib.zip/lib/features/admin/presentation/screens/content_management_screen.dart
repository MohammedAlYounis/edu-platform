import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../../core/constants/app_enums.dart';
import '../../../../shared/widgets/state_views.dart';
import '../../application/admin_providers.dart';
import '../../data/admin_repository.dart';

class ContentManagementScreen extends ConsumerWidget {
  final String subjectId;
  final String? subjectTitle;

  const ContentManagementScreen({super.key, required this.subjectId, this.subjectTitle});

  Future<void> _showAddContentDialog(
    BuildContext context,
    WidgetRef ref, {
    required ContentType type,
    required int nextOrder,
  }) async {
    final titleController = TextEditingController();
    final descController = TextEditingController();
    DateTime? availableFrom;
    DateTime? availableUntil;
    PlatformFile? pickedFile;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: Text(type == ContentType.lesson ? 'إضافة درس' : 'إضافة اختبار'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: titleController,
                  decoration: const InputDecoration(labelText: 'العنوان'),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: descController,
                  decoration: const InputDecoration(labelText: 'الوصف (اختياري)'),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  icon: const Icon(Icons.attach_file),
                  label: Text(pickedFile?.name ?? 'اختيار ملف PDF'),
                  onPressed: () async {
                    final result = await FilePicker.platform
                        .pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
                    if (result != null) setState(() => pickedFile = result.files.single);
                  },
                ),
                if (type == ContentType.exam) ...[
                  const SizedBox(height: 12),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(availableFrom == null
                        ? 'اختر تاريخ البداية'
                        : 'من: ${DateFormat('yyyy/MM/dd hh:mm a').format(availableFrom!)}'),
                    trailing: const Icon(Icons.calendar_today, size: 18),
                    onTap: () async {
                      final date = await _pickDateTime(context);
                      if (date != null) setState(() => availableFrom = date);
                    },
                  ),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(availableUntil == null
                        ? 'اختر تاريخ النهاية'
                        : 'إلى: ${DateFormat('yyyy/MM/dd hh:mm a').format(availableUntil!)}'),
                    trailing: const Icon(Icons.calendar_today, size: 18),
                    onTap: () async {
                      final date = await _pickDateTime(context);
                      if (date != null) setState(() => availableUntil = date);
                    },
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () {
                if (titleController.text.trim().isEmpty || pickedFile?.path == null) return;
                if (type == ContentType.exam &&
                    (availableFrom == null ||
                        availableUntil == null ||
                        !availableUntil!.isAfter(availableFrom!))) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('تأكد من تاريخي البداية والنهاية (النهاية بعد البداية)')),
                  );
                  return;
                }
                Navigator.pop(context, true);
              },
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );

    if (confirmed != true || pickedFile?.path == null) return;

    try {
      await ref.read(adminRepositoryProvider).createContent(
            subjectId: subjectId,
            title: titleController.text.trim(),
            description: descController.text.trim().isEmpty ? null : descController.text.trim(),
            type: type,
            file: File(pickedFile!.path!),
            fileName: pickedFile!.name,
            orderIndex: nextOrder,
            availableFrom: availableFrom,
            availableUntil: availableUntil,
          );
      ref.invalidate(subjectContentsAdminProvider(subjectId));
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('تعذر إضافة المحتوى، حاول مرة أخرى.')));
      }
    }
  }

  Future<DateTime?> _pickDateTime(BuildContext context) async {
    final date = await showDatePicker(
      context: context,
      firstDate: DateTime.now().subtract(const Duration(days: 1)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      initialDate: DateTime.now(),
    );
    if (date == null || !context.mounted) return null;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (time == null) return date;
    return DateTime(date.year, date.month, date.day, time.hour, time.minute);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final contentsAsync = ref.watch(subjectContentsAdminProvider(subjectId));

    return Scaffold(
      appBar: AppBar(title: Text(subjectTitle ?? 'المحتوى')),
      floatingActionButton: contentsAsync.maybeWhen(
        data: (contents) => PopupMenuButton<ContentType>(
          icon: const Icon(Icons.add_circle, size: 48),
          onSelected: (type) => _showAddContentDialog(
            context,
            ref,
            type: type,
            nextOrder: contents.length,
          ),
          itemBuilder: (context) => const [
            PopupMenuItem(value: ContentType.lesson, child: Text('إضافة درس')),
            PopupMenuItem(value: ContentType.exam, child: Text('إضافة اختبار')),
          ],
        ),
        orElse: () => null,
      ),
      body: contentsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => ErrorStateView(
          message: 'تعذر تحميل المحتوى.',
          onRetry: () => ref.invalidate(subjectContentsAdminProvider(subjectId)),
        ),
        data: (contents) {
          if (contents.isEmpty) return const EmptyState(message: 'لا يوجد محتوى بعد.');
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: contents.length,
            itemBuilder: (context, index) {
              final content = contents[index];
              final isLesson = content.type == ContentType.lesson;
              return Card(
                child: ListTile(
                  leading: Icon(
                    isLesson ? Icons.menu_book_outlined : Icons.assignment_outlined,
                    color: isLesson ? Colors.blue : Colors.deepOrange,
                  ),
                  title: Text('${(index + 1).toString().padLeft(2, '0')} - ${content.title}'),
                  subtitle: !isLesson && content.availableUntil != null
                      ? Text('ينتهي: ${DateFormat('yyyy/MM/dd hh:mm a').format(content.availableUntil!)}')
                      : null,
                  trailing: Switch(
                    value: content.isActive,
                    onChanged: (value) async {
                      await ref.read(adminRepositoryProvider).setContentActive(content.id, value);
                      ref.invalidate(subjectContentsAdminProvider(subjectId));
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
