import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/app_enums.dart';
import '../../../../core/routing/app_router.dart';
import '../../../../shared/widgets/state_views.dart';
import '../../../../shared/widgets/status_badge.dart';
import '../../application/admin_providers.dart';

const _filters = <String, SubmissionStatus?>{
  'الكل': null,
  'قيد المراجعة': SubmissionStatus.pending,
  'قيد التصحيح': SubmissionStatus.reviewing,
  'تمت المراجعة': SubmissionStatus.reviewed,
  'يحتاج إعادة إرسال': SubmissionStatus.needsResubmission,
};

class SubmissionsManagementScreen extends ConsumerWidget {
  const SubmissionsManagementScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final rowsAsync = ref.watch(submissionsListProvider);
    final currentFilter = ref.watch(submissionStatusFilterProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('إدارة الحلول')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'ابحث باسم الطالب، رقمه، أو عنوان الاختبار...',
                border: OutlineInputBorder(),
              ),
              onChanged: (v) => ref.read(submissionSearchQueryProvider.notifier).state = v,
            ),
          ),
          SizedBox(
            height: 44,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: _filters.entries.map((entry) {
                final selected = currentFilter == entry.value;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: ChoiceChip(
                    label: Text(entry.key),
                    selected: selected,
                    onSelected: (_) =>
                        ref.read(submissionStatusFilterProvider.notifier).state = entry.value,
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: rowsAsync.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => ErrorStateView(
                message: 'تعذر تحميل الحلول.',
                onRetry: () => ref.invalidate(submissionsListProvider),
              ),
              data: (rows) {
                if (rows.isEmpty) return const EmptyState(message: 'لا توجد حلول مطابقة.');
                return ListView.builder(
                  itemCount: rows.length,
                  itemBuilder: (context, index) {
                    final r = rows[index];
                    return ListTile(
                      title: Text('${r.studentName} — ${r.examTitle}'),
                      subtitle: Text(r.studentNumber ?? ''),
                      trailing: StatusBadge(status: r.status),
                      onTap: () => context
                          .push(AdminRoutes.reviewSubmission.replaceFirst(':id', r.id)),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
