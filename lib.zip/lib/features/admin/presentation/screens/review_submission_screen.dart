import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:reactive_forms/reactive_forms.dart';

import '../../../../core/constants/app_enums.dart';
import '../../../../shared/widgets/pdf_viewer_widget.dart';
import '../../../../shared/widgets/state_views.dart';
import '../../../../shared/widgets/status_badge.dart';
import '../../application/admin_providers.dart';
import '../../data/admin_repository.dart';
import '../../data/models/admin_models.dart';

class ReviewSubmissionScreen extends ConsumerWidget {
  final String submissionId;
  const ReviewSubmissionScreen({super.key, required this.submissionId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final detailsAsync = ref.watch(submissionDetailsProvider(submissionId));

    return Scaffold(
      appBar: AppBar(title: const Text('مراجعة الحل')),
      body: detailsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => ErrorStateView(
          message: 'تعذر تحميل الحل.',
          onRetry: () => ref.invalidate(submissionDetailsProvider(submissionId)),
        ),
        data: (details) => _ReviewBody(details: details),
      ),
    );
  }
}

class _ReviewBody extends ConsumerStatefulWidget {
  final SubmissionDetails details;
  const _ReviewBody({required this.details});

  @override
  ConsumerState<_ReviewBody> createState() => _ReviewBodyState();
}

class _ReviewBodyState extends ConsumerState<_ReviewBody> {
  late final form = FormGroup({
    'grade': FormControl<String>(
      value: widget.details.grade?.toStringAsFixed(0),
      validators: [Validators.number(), Validators.min(0), Validators.max(100)],
    ),
    'note': FormControl<String>(value: widget.details.reviewNote),
  });

  final _resubmissionReasonController = TextEditingController();
  bool _isSaving = false;

  Future<void> _startReviewIfPending() async {
    if (widget.details.status == SubmissionStatus.pending) {
      await ref.read(adminRepositoryProvider).startReview(widget.details.id);
      ref.invalidate(submissionDetailsProvider(widget.details.id));
    }
  }

  Future<void> _saveReview() async {
    if (form.invalid) {
      form.markAllAsTouched();
      return;
    }
    setState(() => _isSaving = true);
    try {
      await ref.read(adminRepositoryProvider).saveReview(
            submissionId: widget.details.id,
            grade: double.parse(form.control('grade').value as String),
            note: (form.control('note').value as String?)?.trim().isEmpty ?? true
                ? null
                : form.control('note').value as String,
          );
      ref.invalidate(submissionDetailsProvider(widget.details.id));
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ التصحيح.')));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('تعذر الحفظ، حاول مرة أخرى.')));
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  Future<void> _requestResubmission() async {
    final reason = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('طلب إعادة إرسال'),
        content: TextField(
          controller: _resubmissionReasonController,
          decoration: const InputDecoration(labelText: 'سبب طلب إعادة الإرسال'),
          maxLines: 2,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () => Navigator.pop(context, _resubmissionReasonController.text.trim()),
            child: const Text('إرسال الطلب'),
          ),
        ],
      ),
    );

    if (reason == null || reason.isEmpty) return;

    await ref.read(adminRepositoryProvider).requestResubmission(
          submissionId: widget.details.id,
          reason: reason,
        );
    ref.invalidate(submissionDetailsProvider(widget.details.id));
  }

  @override
  void initState() {
    super.initState();
    // بند 31: "يجب تسجيل reviewed_at و reviewer_id" — يبدأ عند فتح الشاشة أول مرة
    WidgetsBinding.instance.addPostFrameCallback((_) => _startReviewIfPending());
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.details;

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text(d.studentName, style: Theme.of(context).textTheme.titleLarge),
        Text('الرقم الجامعي: ${d.studentNumber ?? "—"}'),
        const SizedBox(height: 4),
        Text('الاختبار: ${d.examTitle}'),
        const SizedBox(height: 8),
        StatusBadge(status: d.status),
        const SizedBox(height: 16),
        OutlinedButton.icon(
          icon: const Icon(Icons.picture_as_pdf_outlined),
          label: const Text('عرض ملف الحل'),
          onPressed: () => Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => PdfViewerWidget(
                bucket: 'submissions',
                storagePath: d.filePath,
                title: 'حل: ${d.studentName}',
              ),
            ),
          ),
        ),
        const SizedBox(height: 24),
        const Divider(),
        const SizedBox(height: 12),
        Text('التصحيح', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        ReactiveForm(
          formGroup: form,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              ReactiveTextField<String>(
                formControlName: 'grade',
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'العلامة (من 100)'),
                validationMessages: {
                  ValidationMessage.number: (_) => 'أدخل رقمًا صحيحًا',
                  ValidationMessage.min: (_) => 'العلامة يجب أن تكون 0 أو أكثر',
                  ValidationMessage.max: (_) => 'العلامة يجب ألا تتجاوز 100',
                },
              ),
              const SizedBox(height: 12),
              ReactiveTextField<String>(
                formControlName: 'note',
                maxLines: 3,
                decoration: const InputDecoration(labelText: 'ملاحظات (اختياري)'),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _isSaving ? null : _saveReview,
                child: _isSaving
                    ? const SizedBox(
                        height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('حفظ التصحيح'),
              ),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: _requestResubmission,
                child: const Text('طلب إعادة الإرسال'),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
