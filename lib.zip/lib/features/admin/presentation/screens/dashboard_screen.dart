import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../shared/widgets/state_views.dart';
import '../../../../shared/widgets/status_badge.dart';
import '../../application/admin_providers.dart';
import '../../data/models/dashboard_stats.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final statsAsync = ref.watch(dashboardStatsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('لوحة التحكم')),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(dashboardStatsProvider);
          ref.invalidate(recentStudentsProvider);
          ref.invalidate(recentSubmissionsAdminProvider);
        },
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            statsAsync.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => ErrorStateView(
                message: 'تعذر تحميل الإحصائيات.',
                onRetry: () => ref.invalidate(dashboardStatsProvider),
              ),
              data: (stats) => _StatsGrid(stats: stats),
            ),
            const SizedBox(height: 28),
            Text('أحدث الطلاب', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            _RecentStudentsList(),
            const SizedBox(height: 28),
            Text('أحدث الحلول المرسلة', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            _RecentSubmissionsList(),
          ],
        ),
      ),
    );
  }
}

class _StatsGrid extends StatelessWidget {
  final DashboardStats stats;
  const _StatsGrid({required this.stats});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('الطلاب', stats.totalStudents, Icons.people_outline, Colors.blue),
      ('المواد', stats.totalSubjects, Icons.menu_book_outlined, Colors.teal),
      ('الدروس', stats.totalLessons, Icons.article_outlined, Colors.indigo),
      ('الاختبارات', stats.totalExams, Icons.assignment_outlined, Colors.deepPurple),
      ('حلول قيد المراجعة', stats.pendingSubmissions, Icons.hourglass_empty, Colors.orange),
      ('حلول تمت مراجعتها', stats.reviewedSubmissions, Icons.check_circle_outline, Colors.green),
    ];

    return GridView.count(
      crossAxisCount: MediaQuery.sizeOf(context).width >= 900 ? 3 : 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 1.6,
      children: items
          .map((i) => Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Icon(i.$3, color: i.$4),
                      Text('${i.$2}',
                          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                      Text(i.$1, style: const TextStyle(color: Colors.grey)),
                    ],
                  ),
                ),
              ))
          .toList(),
    );
  }
}

class _RecentStudentsList extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(recentStudentsProvider);
    return async.when(
      loading: () => const LinearProgressIndicator(),
      error: (e, _) => const Text('تعذر التحميل.', style: TextStyle(color: Colors.grey)),
      data: (students) {
        if (students.isEmpty) return const Text('لا يوجد طلاب بعد.');
        return Column(
          children: students
              .map((s) => Card(
                    child: ListTile(
                      title: Text(s.fullName),
                      subtitle: Text('الرقم الجامعي: ${s.studentNumber ?? "—"}'),
                    ),
                  ))
              .toList(),
        );
      },
    );
  }
}

class _RecentSubmissionsList extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(recentSubmissionsAdminProvider);
    return async.when(
      loading: () => const LinearProgressIndicator(),
      error: (e, _) => const Text('تعذر التحميل.', style: TextStyle(color: Colors.grey)),
      data: (rows) {
        if (rows.isEmpty) return const Text('لا توجد حلول مرسلة بعد.');
        return Column(
          children: rows
              .map((r) => Card(
                    child: ListTile(
                      title: Text('${r.studentName} — ${r.examTitle}'),
                      subtitle: Text(r.studentNumber ?? ''),
                      trailing: StatusBadge(status: r.status),
                    ),
                  ))
              .toList(),
        );
      },
    );
  }
}
