import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/routing/app_router.dart';
import '../../../../shared/widgets/state_views.dart';
import '../../application/admin_providers.dart';

class StudentsScreen extends ConsumerWidget {
  const StudentsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final studentsAsync = ref.watch(studentsSearchResultProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('الطلاب')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'ابحث بالاسم أو الرقم الجامعي...',
                border: OutlineInputBorder(),
              ),
              onChanged: (value) =>
                  ref.read(studentSearchQueryProvider.notifier).state = value,
            ),
          ),
          Expanded(
            child: studentsAsync.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => ErrorStateView(
                message: 'تعذر تحميل الطلاب.',
                onRetry: () => ref.invalidate(studentsSearchResultProvider),
              ),
              data: (students) {
                if (students.isEmpty) {
                  return const EmptyState(message: 'لا يوجد طلاب مطابقون.');
                }
                return ListView.builder(
                  itemCount: students.length,
                  itemBuilder: (context, index) {
                    final s = students[index];
                    return ListTile(
                      leading: CircleAvatar(child: Text(s.fullName.substring(0, 1))),
                      title: Text(s.fullName),
                      subtitle: Text('${s.studentNumber ?? "—"} • ${s.email}'),
                      trailing: s.isActive
                          ? null
                          : const Chip(label: Text('معطّل'), backgroundColor: Color(0xFFFFE0E0)),
                      onTap: () => context.push(
                        AdminRoutes.studentDetails.replaceFirst(':id', s.id),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
