// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'submission.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$Submission {
  String get id => throw _privateConstructorUsedError;
  String get contentId => throw _privateConstructorUsedError;
  String get studentId => throw _privateConstructorUsedError;
  String get filePath => throw _privateConstructorUsedError;
  String get fileName => throw _privateConstructorUsedError;
  SubmissionStatus get status => throw _privateConstructorUsedError;
  double? get grade => throw _privateConstructorUsedError;
  String? get reviewNote => throw _privateConstructorUsedError;
  DateTime get submittedAt => throw _privateConstructorUsedError;
  DateTime? get reviewedAt => throw _privateConstructorUsedError;
  bool get canResubmit => throw _privateConstructorUsedError;
  String? get resubmissionReason => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $SubmissionCopyWith<Submission> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubmissionCopyWith<$Res> {
  factory $SubmissionCopyWith(
          Submission value, $Res Function(Submission) then) =
      _$SubmissionCopyWithImpl<$Res, Submission>;
  @useResult
  $Res call(
      {String id,
      String contentId,
      String studentId,
      String filePath,
      String fileName,
      SubmissionStatus status,
      double? grade,
      String? reviewNote,
      DateTime submittedAt,
      DateTime? reviewedAt,
      bool canResubmit,
      String? resubmissionReason});
}

/// @nodoc
class _$SubmissionCopyWithImpl<$Res, $Val extends Submission>
    implements $SubmissionCopyWith<$Res> {
  _$SubmissionCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? contentId = null,
    Object? studentId = null,
    Object? filePath = null,
    Object? fileName = null,
    Object? status = null,
    Object? grade = freezed,
    Object? reviewNote = freezed,
    Object? submittedAt = null,
    Object? reviewedAt = freezed,
    Object? canResubmit = null,
    Object? resubmissionReason = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      contentId: null == contentId
          ? _value.contentId
          : contentId // ignore: cast_nullable_to_non_nullable
              as String,
      studentId: null == studentId
          ? _value.studentId
          : studentId // ignore: cast_nullable_to_non_nullable
              as String,
      filePath: null == filePath
          ? _value.filePath
          : filePath // ignore: cast_nullable_to_non_nullable
              as String,
      fileName: null == fileName
          ? _value.fileName
          : fileName // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as SubmissionStatus,
      grade: freezed == grade
          ? _value.grade
          : grade // ignore: cast_nullable_to_non_nullable
              as double?,
      reviewNote: freezed == reviewNote
          ? _value.reviewNote
          : reviewNote // ignore: cast_nullable_to_non_nullable
              as String?,
      submittedAt: null == submittedAt
          ? _value.submittedAt
          : submittedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      reviewedAt: freezed == reviewedAt
          ? _value.reviewedAt
          : reviewedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      canResubmit: null == canResubmit
          ? _value.canResubmit
          : canResubmit // ignore: cast_nullable_to_non_nullable
              as bool,
      resubmissionReason: freezed == resubmissionReason
          ? _value.resubmissionReason
          : resubmissionReason // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SubmissionImplCopyWith<$Res>
    implements $SubmissionCopyWith<$Res> {
  factory _$$SubmissionImplCopyWith(
          _$SubmissionImpl value, $Res Function(_$SubmissionImpl) then) =
      __$$SubmissionImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String contentId,
      String studentId,
      String filePath,
      String fileName,
      SubmissionStatus status,
      double? grade,
      String? reviewNote,
      DateTime submittedAt,
      DateTime? reviewedAt,
      bool canResubmit,
      String? resubmissionReason});
}

/// @nodoc
class __$$SubmissionImplCopyWithImpl<$Res>
    extends _$SubmissionCopyWithImpl<$Res, _$SubmissionImpl>
    implements _$$SubmissionImplCopyWith<$Res> {
  __$$SubmissionImplCopyWithImpl(
      _$SubmissionImpl _value, $Res Function(_$SubmissionImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? contentId = null,
    Object? studentId = null,
    Object? filePath = null,
    Object? fileName = null,
    Object? status = null,
    Object? grade = freezed,
    Object? reviewNote = freezed,
    Object? submittedAt = null,
    Object? reviewedAt = freezed,
    Object? canResubmit = null,
    Object? resubmissionReason = freezed,
  }) {
    return _then(_$SubmissionImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      contentId: null == contentId
          ? _value.contentId
          : contentId // ignore: cast_nullable_to_non_nullable
              as String,
      studentId: null == studentId
          ? _value.studentId
          : studentId // ignore: cast_nullable_to_non_nullable
              as String,
      filePath: null == filePath
          ? _value.filePath
          : filePath // ignore: cast_nullable_to_non_nullable
              as String,
      fileName: null == fileName
          ? _value.fileName
          : fileName // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as SubmissionStatus,
      grade: freezed == grade
          ? _value.grade
          : grade // ignore: cast_nullable_to_non_nullable
              as double?,
      reviewNote: freezed == reviewNote
          ? _value.reviewNote
          : reviewNote // ignore: cast_nullable_to_non_nullable
              as String?,
      submittedAt: null == submittedAt
          ? _value.submittedAt
          : submittedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      reviewedAt: freezed == reviewedAt
          ? _value.reviewedAt
          : reviewedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      canResubmit: null == canResubmit
          ? _value.canResubmit
          : canResubmit // ignore: cast_nullable_to_non_nullable
              as bool,
      resubmissionReason: freezed == resubmissionReason
          ? _value.resubmissionReason
          : resubmissionReason // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

class _$SubmissionImpl implements _Submission {
  const _$SubmissionImpl(
      {required this.id,
      required this.contentId,
      required this.studentId,
      required this.filePath,
      required this.fileName,
      required this.status,
      this.grade,
      this.reviewNote,
      required this.submittedAt,
      this.reviewedAt,
      required this.canResubmit,
      this.resubmissionReason});

  @override
  final String id;
  @override
  final String contentId;
  @override
  final String studentId;
  @override
  final String filePath;
  @override
  final String fileName;
  @override
  final SubmissionStatus status;
  @override
  final double? grade;
  @override
  final String? reviewNote;
  @override
  final DateTime submittedAt;
  @override
  final DateTime? reviewedAt;
  @override
  final bool canResubmit;
  @override
  final String? resubmissionReason;

  @override
  String toString() {
    return 'Submission(id: $id, contentId: $contentId, studentId: $studentId, filePath: $filePath, fileName: $fileName, status: $status, grade: $grade, reviewNote: $reviewNote, submittedAt: $submittedAt, reviewedAt: $reviewedAt, canResubmit: $canResubmit, resubmissionReason: $resubmissionReason)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SubmissionImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.contentId, contentId) ||
                other.contentId == contentId) &&
            (identical(other.studentId, studentId) ||
                other.studentId == studentId) &&
            (identical(other.filePath, filePath) ||
                other.filePath == filePath) &&
            (identical(other.fileName, fileName) ||
                other.fileName == fileName) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.grade, grade) || other.grade == grade) &&
            (identical(other.reviewNote, reviewNote) ||
                other.reviewNote == reviewNote) &&
            (identical(other.submittedAt, submittedAt) ||
                other.submittedAt == submittedAt) &&
            (identical(other.reviewedAt, reviewedAt) ||
                other.reviewedAt == reviewedAt) &&
            (identical(other.canResubmit, canResubmit) ||
                other.canResubmit == canResubmit) &&
            (identical(other.resubmissionReason, resubmissionReason) ||
                other.resubmissionReason == resubmissionReason));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      contentId,
      studentId,
      filePath,
      fileName,
      status,
      grade,
      reviewNote,
      submittedAt,
      reviewedAt,
      canResubmit,
      resubmissionReason);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SubmissionImplCopyWith<_$SubmissionImpl> get copyWith =>
      __$$SubmissionImplCopyWithImpl<_$SubmissionImpl>(this, _$identity);
}

abstract class _Submission implements Submission {
  const factory _Submission(
      {required final String id,
      required final String contentId,
      required final String studentId,
      required final String filePath,
      required final String fileName,
      required final SubmissionStatus status,
      final double? grade,
      final String? reviewNote,
      required final DateTime submittedAt,
      final DateTime? reviewedAt,
      required final bool canResubmit,
      final String? resubmissionReason}) = _$SubmissionImpl;

  @override
  String get id;
  @override
  String get contentId;
  @override
  String get studentId;
  @override
  String get filePath;
  @override
  String get fileName;
  @override
  SubmissionStatus get status;
  @override
  double? get grade;
  @override
  String? get reviewNote;
  @override
  DateTime get submittedAt;
  @override
  DateTime? get reviewedAt;
  @override
  bool get canResubmit;
  @override
  String? get resubmissionReason;
  @override
  @JsonKey(ignore: true)
  _$$SubmissionImplCopyWith<_$SubmissionImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
