import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../../core/constants/app_enums.dart';
import '../../../../shared/models/content.dart';
import '../../../../shared/widgets/pdf_viewer_widget.dart';
import '../../../../shared/widgets/state_views.dart';
import '../../../../shared/widgets/status_badge.dart';
import '../../../submissions/application/submissions_providers.dart';
import '../../../submissions/data/models/submission.dart';
import '../../../subjects/application/subjects_providers.dart';

class ExamScreen extends ConsumerWidget {
  final String contentId;
  const ExamScreen({super.key, required this.contentId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final contentAsync = ref.watch(contentByIdProvider(contentId));

    return Scaffold(
      appBar: AppBar(title: const Text('الاختبار')),
      body: contentAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => ErrorStateView(
          message: 'تعذر تحميل بيانات الاختبار.',
          onRetry: () => ref.invalidate(contentByIdProvider(contentId)),
        ),
        data: (content) => _ExamBody(content: content),
      ),
    );
  }
}

class _ExamBody extends ConsumerWidget {
  final Content content;
  const _ExamBody({required this.content});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final submissionAsync = ref.watch(mySubmissionProvider(content.id));
    final dateFmt = DateFormat('yyyy/MM/dd - hh:mm a');

    return submissionAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => ErrorStateView(
        message: 'تعذر تحميل حالة الحل.',
        onRetry: () => ref.invalidate(mySubmissionProvider(content.id)),
      ),
      data: (submission) {
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(content.title, style: Theme.of(context).textTheme.headlineSmall),
            if (content.description != null) ...[
              const SizedBox(height: 8),
              Text(content.description!),
            ],
            const SizedBox(height: 16),
            _InfoRow(
              icon: Icons.play_circle_outline,
              label: 'بداية الاختبار',
              value: content.availableFrom != null ? dateFmt.format(content.availableFrom!) : '—',
            ),
            _InfoRow(
              icon: Icons.stop_circle_outlined,
              label: 'نهاية الاختبار',
              value: content.availableUntil != null ? dateFmt.format(content.availableUntil!) : '—',
            ),
            const SizedBox(height: 20),
            OutlinedButton.icon(
              icon: const Icon(Icons.picture_as_pdf_outlined),
              label: const Text('فتح الأسئلة'),
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => PdfViewerWidget(
                    bucket: 'exams',
                    storagePath: content.filePath,
                    title: content.title,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),
            const Divider(),
            const SizedBox(height: 12),
            Text('حالة الحل', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            _SubmissionSection(content: content, submission: submission),
          ],
        );
      },
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _InfoRow({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 18, color: Colors.grey),
          const SizedBox(width: 8),
          Text('$label: '),
          Expanded(child: Text(value, textAlign: TextAlign.end)),
        ],
      ),
    );
  }
}

class _SubmissionSection extends ConsumerWidget {
  final Content content;
  final Submission? submission;
  const _SubmissionSection({required this.content, required this.submission});

  Future<void> _pickAndConfirm(BuildContext context, WidgetRef ref) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );
    if (result == null || result.files.single.path == null) return;

    final path = result.files.single.path!;
    final fileName = result.files.single.name;
    final file = File(path);
    final sizeKb = (await file.length()) / 1024;

    if (!context.mounted) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تأكيد الإرسال'),
        content: Text(
          'الملف: $fileName\nالحجم: ${sizeKb.toStringAsFixed(0)} KB\n\n'
          'يمكنك إرسال حل واحد فقط لهذا الاختبار. بعد الإرسال لن تتمكن '
          'من تغييره إلا إذا سمحت الإدارة بإعادة الإرسال.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('إرسال الحل')),
        ],
      ),
    );

    if (confirmed != true || !context.mounted) return;

    await ref.read(submissionUploadProvider(content.id).notifier).upload(file, fileName);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final uploadState = ref.watch(submissionUploadProvider(content.id));

    ref.listen(submissionUploadProvider(content.id), (previous, next) {
      if (next.status == UploadStatus.error && next.errorMessage != null) {
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(SnackBar(content: Text(next.errorMessage!)));
      }
      if (next.status == UploadStatus.success) {
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(const SnackBar(content: Text('تم إرسال الحل بنجاح.')));
      }
    });

    // لا يوجد حل بعد → إظهار زر الرفع إن كان الاختبار متاحًا فعليًا
    if (submission == null) {
      if (!content.canAcceptSubmission) {
        return Text(
          content.availability == ExamAvailability.upcoming
              ? 'الاختبار لم يبدأ بعد.'
              : 'انتهى وقت هذا الاختبار، لا يمكن إرسال حل.',
          style: const TextStyle(color: Colors.grey),
        );
      }
      return ElevatedButton.icon(
        icon: uploadState.status == UploadStatus.uploading
            ? const SizedBox(
                height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2))
            : const Icon(Icons.upload_file),
        label: const Text('رفع الحل'),
        onPressed:
            uploadState.status == UploadStatus.uploading ? null : () => _pickAndConfirm(context, ref),
      );
    }

    // يوجد حل — اعرض الحالة والنتيجة إن وُجدت
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        StatusBadge(status: submission!.status),
        const SizedBox(height: 12),
        if (submission!.status == SubmissionStatus.reviewed) ...[
          Text('العلامة: ${submission!.grade?.toStringAsFixed(0) ?? '—'} / 100',
              style: Theme.of(context).textTheme.titleMedium),
          if (submission!.reviewNote != null) ...[
            const SizedBox(height: 8),
            const Text('ملاحظات المسؤول:'),
            Text(submission!.reviewNote!),
          ],
        ],
        if (submission!.status == SubmissionStatus.needsResubmission && submission!.canResubmit) ...[
          Text(
            'طلبت الإدارة إعادة إرسال الحل.'
            '${submission!.resubmissionReason != null ? '\nالسبب: ${submission!.resubmissionReason}' : ''}',
            style: const TextStyle(color: Colors.red),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            icon: const Icon(Icons.upload_file),
            label: const Text('رفع حل جديد'),
            onPressed: uploadState.status == UploadStatus.uploading
                ? null
                : () => _pickAndConfirm(context, ref),
          ),
        ],
      ],
    );
  }
}
