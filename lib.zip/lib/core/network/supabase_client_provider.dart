import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../errors/failure.dart';

/// Provider وحيد للوصول إلى Supabase Client عبر كامل المشروع.
/// لا تستدعِ Supabase.instance.client مباشرة داخل الـ Repositories —
/// مرّر هذا الـ provider بدلًا من ذلك، لتسهيل الاختبار والاستبدال لاحقًا.
final supabaseClientProvider = Provider<SupabaseClient>((ref) {
  return Supabase.instance.client;
});

/// يحوّل أي استثناء قادم من Supabase/الشبكة إلى Failure واضح للمستخدم.
/// استخدمه في كل Repository داخل try/catch بدل تمرير الخطأ الخام للـ UI.
Failure mapExceptionToFailure(Object error, [StackTrace? stackTrace]) {
  if (error is AuthException) {
    return AuthFailure(_mapAuthMessage(error.message), debugDetails: '$error');
  }
  if (error is PostgrestException) {
    if (error.code == 'PGRST301' || error.code == '42501') {
      return PermissionFailure(debugDetails: '$error');
    }
    return UnknownFailure(debugDetails: '$error');
  }
  if (error is StorageException) {
    return StorageFailure('تعذر رفع أو تنزيل الملف، حاول مرة أخرى.',
        debugDetails: '$error');
  }
  return UnknownFailure(debugDetails: '$error\n$stackTrace');
}

String _mapAuthMessage(String raw) {
  // رسائل Supabase الافتراضية تأتي بالإنجليزية؛ نترجم الحالات الشائعة فقط.
  final message = raw.toLowerCase();
  if (message.contains('invalid login credentials')) {
    return 'البريد الإلكتروني أو كلمة المرور غير صحيحة.';
  }
  if (message.contains('already registered') ||
      message.contains('user already registered')) {
    return 'هذا البريد الإلكتروني مسجّل مسبقًا.';
  }
  if (message.contains('email not confirmed')) {
    return 'Please confirm your email before signing in.';
  }
  return 'Unable to sign in. Please try again.';
}
