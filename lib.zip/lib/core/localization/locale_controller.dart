import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'app_localizations.dart';

const _settingsBoxName = 'app_settings';
const _localeKey = 'locale';

final localeProvider = StateNotifierProvider<LocaleController, Locale>(
    (ref) => LocaleController());

class LocaleController extends StateNotifier<Locale> {
  LocaleController()
      : super(Locale(
            Hive.box(_settingsBoxName).get(_localeKey, defaultValue: 'en')));

  Future<void> setLocale(Locale locale) async {
    if (!AppLocalizations.supportedLocales
        .any((supported) => supported.languageCode == locale.languageCode)) {
      return;
    }
    state = locale;
    await Hive.box(_settingsBoxName).put(_localeKey, locale.languageCode);
  }

  Future<void> toggle() => setLocale(
        state.languageCode == 'en' ? const Locale('ar') : const Locale('en'),
      );
}
