/// كل خطأ في التطبيق يُحوَّل إلى Failure قبل أن يصل إلى الـ UI،
/// بحيث لا تظهر رسائل تقنية (PostgrestException، SocketException...) للمستخدم النهائي.
sealed class Failure {
  final String message; // رسالة صالحة للعرض للمستخدم (تُترجم لاحقًا)
  final String? debugDetails; // للـ logging فقط، لا تُعرض أبدًا

  const Failure(this.message, {this.debugDetails});
}

class NetworkFailure extends Failure {
  const NetworkFailure({String? debugDetails})
      : super('تعذر الاتصال بالخادم، تحقق من الإنترنت وحاول مرة أخرى.',
            debugDetails: debugDetails);
}

class AuthFailure extends Failure {
  const AuthFailure(super.message, {super.debugDetails});
}

class ValidationFailure extends Failure {
  const ValidationFailure(super.message, {super.debugDetails});
}

class PermissionFailure extends Failure {
  const PermissionFailure({String? debugDetails})
      : super('ليست لديك صلاحية القيام بهذا الإجراء.',
            debugDetails: debugDetails);
}

class NotFoundFailure extends Failure {
  const NotFoundFailure({String? debugDetails})
      : super('العنصر المطلوب غير موجود.', debugDetails: debugDetails);
}

class StorageFailure extends Failure {
  const StorageFailure(super.message, {super.debugDetails});
}

class UnknownFailure extends Failure {
  const UnknownFailure({String? debugDetails})
      : super('حدث خطأ غير متوقع، حاول مرة أخرى.', debugDetails: debugDetails);
}
